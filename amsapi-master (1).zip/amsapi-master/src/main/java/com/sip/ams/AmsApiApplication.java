package com.sip.ams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmsApiApplication.class, args);
	}

}
