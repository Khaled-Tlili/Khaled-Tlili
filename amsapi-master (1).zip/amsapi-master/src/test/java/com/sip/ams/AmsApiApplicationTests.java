package com.sip.ams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
